Image folder for AI Summer images
